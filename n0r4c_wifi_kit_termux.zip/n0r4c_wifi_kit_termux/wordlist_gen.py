#!/usr/bin/env python3
# ============================================
# Gerador de wordlists personalizadas para WPA/WPA2
# Uso: python wordlist_gen.py --default
#      python wordlist_gen.py --name "casa" --year 2024 --output lista.txt
# ============================================

import argparse
import itertools
import os

def gerar_padroes_base():
    """Gera padrões comuns de senhas brasileiras."""
    padroes = []
    
    # Senhas numéricas simples
    for i in range(0, 100000000):
        padroes.append(f"{i:08d}")
    
    return padroes

def gerar_com_nome(nome, ano):
    """Gera combinações baseadas em nome + ano."""
    combinacoes = []
    variacoes = [
        nome,
        nome.lower(),
        nome.upper(),
        nome.capitalize(),
        f"{nome}{ano}",
        f"{nome.lower()}{ano}",
        f"{nome.capitalize()}{ano}",
        f"{ano}{nome}",
        f"{nome}@{ano}",
        f"{nome}#{ano}",
        f"{nome}!{ano}",
        f"{nome}.{ano}",
        f"{nome}_{ano}",
        f"{nome}-{ano}",
    ]
    
    # Adiciona sufixos comuns
    sufixos = ["123", "1234", "12345", "123456", "2023", "2024", "2025", "2026"]
    for base in [nome, nome.lower(), nome.capitalize()]:
        for suf in sufixos:
            combinacoes.append(f"{base}{suf}")
            combinacoes.append(f"{base}@{suf}")
    
    return variacoes + combinacoes

def gerar_palavras_comuns():
    """Lista de palavras-chave comuns em senhas."""
    return [
        "senha", "password", "wifi", "internet", "casa", "familia",
        "amor", "deus", "jesus", "brasil", "admin", "administrador",
        "router", "modem", "fibra", "vivo", "claro", "oi", "tim",
        "net", "gvt", "telecom", "conecta", "rede"
    ]

def main():
    parser = argparse.ArgumentParser(description="Gerador de wordlists")
    parser.add_argument("--default", action="store_true",
                        help="Gera wordlist padrão com padrões comuns")
    parser.add_argument("--name", type=str, default="",
                        help="Nome/sobrenome para gerar combinações")
    parser.add_argument("--year", type=str, default="2024",
                        help="Ano para combinações")
    parser.add_argument("--output", type=str, default="wordlists/common.txt",
                        help="Arquivo de saída")
    
    args = parser.parse_args()
    
    print("[*] Gerando wordlist...")
    
    senhas = set()
    
    if args.default:
        print("[*] Gerando padrões numéricos (8 dígitos)...")
        # Limita a 1 milhão para não travar o celular
        for i in range(1000000):
            senhas.add(f"{i:08d}")
        
        print("[*] Adicionando palavras comuns...")
        palavras = gerar_palavras_comuns()
        
        sufixos = ["123", "1234", "12345", "@1234"]
        
        for palavra in palavras:
            senhas.add(palavra)
            senhas.add(palavra.capitalize())
            for suf in sufixos:
                senhas.add(f"{palavra}{suf}")
                senhas.add(f"{palavra.capitalize()}{suf}")
    
    if args.name:
        print(f"[*] Gerando combinações para '{args.name}'...")
        combinacoes = gerar_com_nome(args.name, args.year)
        senhas.update(combinacoes)
    
    print(f"[*] Escrevendo {len(senhas)} senhas em {args.output}...")
    
    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    
    with open(args.output, 'w') as f:
        for senha in sorted(senhas):
            f.write(senha + '\n')
    
    print(f"[+] Wordlist gerada: {args.output}")
    print(f"[+] Total: {len(senhas)} senhas")

if __name__ == "__main__":
    main()
