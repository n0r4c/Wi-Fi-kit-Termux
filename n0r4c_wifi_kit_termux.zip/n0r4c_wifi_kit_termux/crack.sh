#!/data/data/com.termux/files/usr/bin/bash
# ============================================
# Quebra de senha WPA/WPA2
# Uso: ./crack.sh <arquivo.hc22000> [wordlist]
# ============================================

HASH_FILE="${1:-}"
WORDLIST="${2:-wordlists/common.txt}"

if [[ -z "$HASH_FILE" ]]; then
    echo "[!] Uso: ./crack.sh <arquivo.hc22000> [wordlist]"
    exit 1
fi

if [[ ! -f "$HASH_FILE" ]]; then
    echo "[!] Arquivo não encontrado: $HASH_FILE"
    exit 1
fi

if [[ ! -f "$WORDLIST" ]]; then
    python wordlist_gen.py --default > "$WORDLIST"
fi

echo "[*] Iniciando quebra com hashcat..."

if command -v hashcat &> /dev/null; then
    hashcat -m 22000 "$HASH_FILE" "$WORDLIST" --force --status --show > resultado.txt 2>&1 || true
    
else
    
fi

grep ":" resultado.txt | head -5 || echo "Senha não encontrada na wordlist."
