#!/data/data/com.termux/files/usr/bin/bash
# ============================================
# Instalação completa do kit Wi-Fi no Termux
# ============================================

set -e

echo "[*] Atualizando pacotes base..."
pkg update -y && pkg upgrade -y

echo "[*] Instalando repositórios extras..."
pkg install -y root-repo x11-repo

echo "[*] Instalando ferramentas de rede..."
pkg install -y \
    aircrack-ng \
    hashcat \
    hcxtools \
    tsu \
    nmap \
    net-tools \
    iw \
    wireless-tools

echo "[*] Instalando utilitários..."
pkg install -y \
    python \
    python-pip \
    git \
    curl \
    wget \
    openssl \
    termux-api

echo "[*] Instalando módulos Python..."
pip install --upgrade pip
pip install scapy pycryptodome

echo "[*] Verificando root..."
if command -v tsu &> /dev/null; then
    echo "[+] tsu instalado. Verifique se o aparelho está rooteado."
else
    echo "[!] tsu não instalado. Tentando novamente..."
    pkg install -y tsu
fi

echo "[*] Dando permissão de execução aos scripts..."
chmod +x scan.sh capture.sh crack.sh evil_twin.sh

echo "[+] Instalação concluída!"
echo "[*] Próximo passo: execute ./scan.sh"
