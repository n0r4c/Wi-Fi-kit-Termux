# N0R4C Wi-Fi kit Termux — Análise de Redes Wi-Fi

Kit completo para análise e teste de segurança de redes Wi-Fi usando apenas um celular Android com Termux.

## Requisitos

- **Android** com Termux instalado (F-Droid)
- **Root** (obrigatório para captura de handshake e modo monitor)
- **Adaptador USB Wi-Fi externo** (recomendado — a maioria dos chips integrados não suporta modo monitor)

## Instalação

```bash
chmod +x install.sh && ./install.sh
