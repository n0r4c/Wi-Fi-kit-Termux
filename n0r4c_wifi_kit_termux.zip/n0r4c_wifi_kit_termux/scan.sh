#!/data/data/com.termux/files/usr/bin/bash
# ============================================
# Escaneamento de redes Wi-Fi
# ============================================

echo "[*] Verificando modo monitor..."

# Verifica se tem root
if command -v tsu &> /dev/null; then
    echo "[*] Root detectado. Tentando modo monitor..."
    tsu -c "
        ip link set wlan0 down 2>/dev/null
        iw dev wlan0 set type monitor 2>/dev/null
        ip link set wlan0 up 2>/dev/null
        echo '[+] Modo monitor ativado em wlan0'
    " || echo "[!] Falha ao ativar modo monitor. Usando modo normal."
else
    echo "[!] Sem root. Usando escaneamento via API Android."
fi

echo ""
echo "[*] Escaneando redes ao redor..."
echo "=========================================="

# Tenta modo monitor primeiro
if tsu -c "iw dev wlan0 info" 2>/dev/null | grep -q "type monitor"; then
    tsu -c "airodump-ng wlan0 --band bg"
else
    # Fallback: API Android
    termux-wifi-scaninfo 2>/dev/null || {
        echo "[!] termux-api não disponível. Instale: pkg install termux-api"
        echo "[*] Tentando com iw..."
        iw dev wlan0 scan 2>/dev/null | grep -E "SSID:|signal:" || echo "[!] Falha no escaneamento."
    }
fi

echo ""
echo "[*] Escaneamento concluído."
echo "[*] Anote o BSSID e canal da rede alvo para usar no capture.sh"
