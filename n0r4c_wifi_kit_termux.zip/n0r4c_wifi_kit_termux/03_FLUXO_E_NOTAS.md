# Fluxo completo passo a passo

Passo 1 — Escaneamento (scan.sh)
Identifica todas as redes ao redor, mostrando SSID, BSSID, canal e força do sinal.

Passo 2 — Captura (capture.sh)
Captura o handshake WPA/WPA2 da rede alvo. O handshake é o momento em que um dispositivo legítimo se conecta à rede.

Passo 3 — Quebra (crack.sh)
Testa a senha capturada contra uma wordlist usando hashcat ou aircrack-ng.

Passo 4 — Wordlists (wordlist_gen.py)
Gera listas personalizadas baseadas em nomes, anos e padrões comuns brasileiros.

Passo 5 — Evil Twin (evil_twin.sh)
Clona a rede alvo e captura credenciais quando a vítima se conecta ao AP falso.

# Notas importantes

	•	Modo monitor: a maioria dos chips Wi-Fi integrados em celulares NÃO suporta modo monitor. Use um adaptador USB externo (chipset Realtek RTL8812AU ou similar).

	•	Performance: quebrar senha no celular é lento. Para senhas complexas, transfira o arquivo .hc22000 para um PC com GPU.

	•	Wordlists: comece com wordlists/common.txt (padrões brasileiros). Para mais cobertura, baixe rockyou.txt (14M+ senhas) e use no PC.

	•	Legalidade: use apenas em redes que você possui ou tem autorização explícita para testar.
